from setuptools import setup
setup(
    name = 'RSS_reader',
    version = '1.0',
    description = 'Command-line RSS-parser',
    author = 'Ann Shimko',
    py_modules = ['RSS_reader'],
)